// import React, { useState, useEffect, useRef } from 'react'
// import { Link } from 'react-router-dom'
// import RegionSeo from '../../us/components/RegionSeo.jsx'
// import {
//   aeAcademicLevels,
//   aeAcademicGroups,
//   aeCurriculum,
//   aeSubjects,
//   aeLocations,
//   aeTestPrep,
//   aeTestimonials,
//   aeHowItWorks,
//   aeWhyChooseUs,
//   aeFaqs,
// } from '../data/aeContent.js'
// import { SITE } from '../../../config/site.js'
// import { expertTeachers } from '../../../data/expertTeachers.js'

// /**
//  * UAEHome — the homepage of the United Arab Emirates regional frontend.
//  *
//  * Section composition:
//  *   Hero (with embedded "Find My Tutor" mini-form: Curriculum + Academic Level + Subject) →
//  *   TrustStrip →
//  *   WhyChooseUs (6-card grid — UAE-specific) →
//  *   HowItWorks (5-step — Educational Consultant terminology) →
//  *   Subjects (popular subjects grid — Arabic featured) →
//  *   AcademicLevels (KG, Primary, Middle, Secondary, Examination Years) →
//  *   CurriculumOptions (NEW — 6 cards: MOE, British, American, IB, CBSE, ICSE) →
//  *   TestPrep (GCSE, A-Level, IB, CBSE Board, MOE Exam) →
//  *   Locations (Abu Dhabi primary) →
//  *   Tutors (verified online tutors — global pool) →
//  *   Testimonials (clearly marked Demo) →
//  *   FAQ (UAE-specific) →
//  *   FinalCTA
//  *
//  * Per spec §9: Premium navy/white design, subtle gold accents (NOT primary fills).
//  * Currency AED. British English spelling throughout.
//  * Initial marketing focus: Abu Dhabi.
//  */

// const HERO_STATS = [
//   { label: 'Verified Tutors', value: '100', suffix: '+' },
//   { label: 'Multi-Curriculum Support', value: '6', suffix: ' curricula' },
//   { label: 'Across the UAE', value: '5', suffix: ' Emirates' },
//   { label: 'Years of Tutoring Excellence', value: SITE.stats?.yearsExperience || '13', suffix: '' },
// ]

// const TRUST_STRIP = [
//   { label: 'Background-checked tutors', icon: '✓' },
//   { label: 'Multi-curriculum support', icon: '🏛️' },
//   { label: 'Free demo class first', icon: '🎬' },
//   { label: 'Dedicated UAE educational consultant', icon: '🤝' },
// ]

// export default function UAEHome() {
//   return (
//     <>
//       <RegionSeo path="/ae" />
//       <Hero />
//       <TrustStrip />
//       <WhyChooseUs />
//       <HowItWorks />
//       <SubjectsGrid />
//       <AcademicLevels />
//       <CurriculumOptions />
//       <TestPrep />
//       <LocationsGrid />
//       <VerifiedTutors />
//       <Testimonials />
//       <FAQ />
//       <FinalCTA />
//     </>
//   )
// }

// /* ============================================================
//    HERO — deep navy night sky, two-column, embedded mini-form
//    ============================================================ */

// function Hero() {
//   const [form, setForm] = useState({ curriculum: '', level: '', subject: '' })

//   const handleQuickSubmit = (e) => {
//     e.preventDefault()
//     const params = new URLSearchParams()
//     if (form.curriculum) params.set('curriculum', form.curriculum)
//     if (form.level) params.set('level', form.level)
//     if (form.subject) params.set('subject', form.subject)
//     window.location.href = `/ae/find-tutor?${params.toString()}`
//   }

//   return (
//     <section className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 text-white">
//       {/* Decorative grid */}
//       <div
//         className="absolute inset-0 opacity-[0.06] pointer-events-none"
//         style={{
//           backgroundImage:
//             'linear-gradient(to right, white 1px, transparent 1px), linear-gradient(to bottom, white 1px, transparent 1px)',
//           backgroundSize: '48px 48px',
//         }}
//         aria-hidden="true"
//       />
//       {/* Glow orbs — subtle gold + navy */}
//       <div className="absolute -top-12 -right-12 h-72 w-72 bg-blue-500/20 blur-3xl rounded-full" aria-hidden="true" />
//       <div className="absolute -bottom-12 -left-12 h-72 w-72 bg-amber-500/10 blur-3xl rounded-full" aria-hidden="true" />

//       <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24 lg:py-28">
//         <div className="grid lg:grid-cols-[1.1fr_0.9fr] gap-10 lg:gap-16 items-center">
//           {/* Left: copy */}
//           <div>
//             <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 text-blue-100 text-xs font-semibold uppercase tracking-wider mb-6">
//               <span className="h-1.5 w-1.5 rounded-full bg-amber-400 animate-pulse" />
//               Now serving families across the UAE
//             </div>
//             <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight leading-[1.1] text-balance">
//               Find trusted tutors for your{' '}
//               <span className="bg-gradient-to-r from-amber-300 to-amber-500 bg-clip-text text-transparent">
//                 curriculum and goals
//               </span>
//               .
//             </h1>
//             <p className="mt-5 text-lg text-blue-100/90 leading-relaxed max-w-xl">
//               Verified online tutors across MOE, British, American, IB, CBSE, and ICSE
//               curricula. Personalised, premium, and always demo-first. From Abu Dhabi to
//               Dubai — across all the Emirates.
//             </p>

//             {/* CTA row */}
//             <div className="mt-7 flex flex-wrap items-center gap-3">
//               <Link
//                 to="/ae/find-tutor"
//                 className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-semibold transition-colors shadow-lg shadow-blue-900/30"
//               >
//                 Find My Tutor →
//               </Link>
//               <a
//                 href={`tel:${SITE.phoneHref}`}
//                 className="inline-flex items-center gap-2 px-5 py-3 rounded-xl border border-white/20 text-white hover:bg-white/10 transition-colors"
//               >
//                 📞 {SITE.phoneDisplay}
//               </a>
//             </div>

//             {/* Stats */}
//             <div className="mt-10 grid grid-cols-2 sm:grid-cols-4 gap-4">
//               {HERO_STATS.map((s) => (
//                 <StatBlock key={s.label} stat={s} />
//               ))}
//             </div>
//           </div>

//           {/* Right: mini-form */}
//           <div className="bg-white/95 backdrop-blur-xl rounded-2xl p-6 sm:p-7 shadow-2xl border border-white/20">
//             <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-50 text-amber-800 text-xs font-semibold mb-3">
//               <span className="h-1.5 w-1.5 rounded-full bg-amber-600 animate-pulse" />
//               Quick match — 3 minutes
//             </div>
//             <h2 className="font-display text-xl font-bold text-slate-900 mb-1">
//               Tell us what you need
//             </h2>
//             <p className="text-sm text-slate-600 mb-4">
//               Get matched with 2–3 verified tutors in your curriculum and academic level.
//             </p>
//             <form onSubmit={handleQuickSubmit} className="space-y-3">
//               <div>
//                 <label className="text-xs font-semibold text-slate-700 mb-1 block">Curriculum</label>
//                 <select
//                   value={form.curriculum}
//                   onChange={(e) => setForm((f) => ({ ...f, curriculum: e.target.value }))}
//                   className="w-full px-3 py-2.5 rounded-lg border border-slate-300 text-sm focus:border-blue-700 focus:ring-2 focus:ring-blue-200 outline-none"
//                 >
//                   <option value="">Select a curriculum</option>
//                   <option value="uae-moe">UAE / MOE Curriculum</option>
//                   <option value="british">British Curriculum</option>
//                   <option value="american">American Curriculum</option>
//                   <option value="ib">IB Curriculum</option>
//                   <option value="cbse">CBSE (Indian)</option>
//                   <option value="icse">ICSE (Indian)</option>
//                 </select>
//               </div>
//               <div>
//                 <label className="text-xs font-semibold text-slate-700 mb-1 block">Academic Level</label>
//                 <select
//                   value={form.level}
//                   onChange={(e) => setForm((f) => ({ ...f, level: e.target.value }))}
//                   className="w-full px-3 py-2.5 rounded-lg border border-slate-300 text-sm focus:border-blue-700 focus:ring-2 focus:ring-blue-200 outline-none"
//                 >
//                   <option value="">Select a level</option>
//                   <optgroup label="Early Years">
//                     <option value="kg">KG (Kindergarten)</option>
//                   </optgroup>
//                   <optgroup label="Primary">
//                     <option value="primary">Primary School</option>
//                   </optgroup>
//                   <optgroup label="Middle">
//                     <option value="middle-school">Middle School</option>
//                     <option value="secondary">Secondary</option>
//                   </optgroup>
//                   <optgroup label="Examination Years">
//                     <option value="gcse">GCSE</option>
//                     <option value="igcse">IGCSE</option>
//                     <option value="a-level">A-Level</option>
//                     <option value="ib">IB Diploma</option>
//                   </optgroup>
//                 </select>
//               </div>
//               <div>
//                 <label className="text-xs font-semibold text-slate-700 mb-1 block">Subject</label>
//                 <select
//                   value={form.subject}
//                   onChange={(e) => setForm((f) => ({ ...f, subject: e.target.value }))}
//                   className="w-full px-3 py-2.5 rounded-lg border border-slate-300 text-sm focus:border-blue-700 focus:ring-2 focus:ring-blue-200 outline-none"
//                 >
//                   <option value="">Select a subject</option>
//                   {aeSubjects.map((s) => (
//                     <option key={s.slug} value={s.slug}>{s.label}</option>
//                   ))}
//                 </select>
//               </div>
//               <button
//                 type="submit"
//                 className="w-full px-4 py-3 rounded-lg bg-blue-900 hover:bg-blue-800 text-white text-sm font-semibold transition-colors shadow-sm"
//               >
//                 Find My Tutor →
//               </button>
//               <p className="text-xs text-slate-500 text-center">
//                 No payment required. Free educational consultant consultation + free demo class.
//               </p>
//             </form>
//           </div>
//         </div>
//       </div>
//     </section>
//   )
// }

// function StatBlock({ stat }) {
//   const ref = useRef(null)
//   const [val, setVal] = useState(0)
//   const [done, setDone] = useState(false)

//   useEffect(() => {
//     if (!ref.current || done) return
//     const target = parseFloat(String(stat.value).replace(/[^\d.]/g, '')) || 0
//     if (!target || !isFinite(target)) {
//       setVal(stat.value)
//       setDone(true)
//       return
//     }
//     const obs = new IntersectionObserver(
//       (entries) => {
//         if (entries[0].isIntersecting) {
//           const start = performance.now()
//           const dur = 1400
//           const tick = (now) => {
//             const t = Math.min(1, (now - start) / dur)
//             const eased = 1 - Math.pow(1 - t, 3)
//             const current = target * eased
//             setVal(stat.value % 1 !== 0 ? current.toFixed(1) : Math.round(current).toLocaleString('en-GB'))
//             if (t < 1) requestAnimationFrame(tick)
//             else setVal(stat.value)
//           }
//           requestAnimationFrame(tick)
//           setDone(true)
//         }
//       },
//       { threshold: 0.4 }
//     )
//     obs.observe(ref.current)
//     return () => obs.disconnect()
//   }, [stat.value, done])

//   return (
//     <div ref={ref} className="text-center sm:text-left">
//       <div className="font-display text-2xl sm:text-3xl font-bold tabular-nums">
//         {val}{stat.suffix}
//       </div>
//       <div className="text-xs text-blue-200/80 mt-1">{stat.label}</div>
//     </div>
//   )
// }

// /* ============================================================
//    TRUST STRIP
//    ============================================================ */

// function TrustStrip() {
//   return (
//     <section className="bg-blue-50 border-y border-blue-100">
//       <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
//         <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
//           {TRUST_STRIP.map((item) => (
//             <div key={item.label} className="flex items-center gap-3">
//               <span className="flex h-9 w-9 items-center justify-center rounded-full bg-white text-blue-900 shadow-sm text-sm font-bold">
//                 {item.icon}
//               </span>
//               <span className="text-sm font-medium text-slate-700">{item.label}</span>
//             </div>
//           ))}
//         </div>
//       </div>
//     </section>
//   )
// }

// /* ============================================================
//    WHY CHOOSE US
//    ============================================================ */

// function WhyChooseUs() {
//   return (
//     <section className="py-16 sm:py-20 bg-white">
//       <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
//         <SectionHeading
//           eyebrow="Why families choose us"
//           title="Built for UAE families, designed for every curriculum"
//           desc="Srijee Tutor brings a global tutoring methodology to the UAE — adapted for MOE, British, American, IB, CBSE, and ICSE curricula, with native Arabic support."
//         />
//         <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 mt-10">
//           {aeWhyChooseUs.map((feature, i) => (
//             <div
//               key={feature.title}
//               style={{ animationDelay: `${i * 60}ms` }}
//               className="bg-white rounded-2xl border border-slate-200 p-6 hover:shadow-lg hover:-translate-y-0.5 transition-all animate-fade-up"
//             >
//               <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-blue-50 text-blue-900 text-xl mb-4">
//                 {feature.icon}
//               </div>
//               <h3 className="font-display text-lg font-bold text-slate-900 mb-2">
//                 {feature.title}
//               </h3>
//               <p className="text-sm text-slate-600 leading-relaxed">{feature.desc}</p>
//             </div>
//           ))}
//         </div>
//       </div>
//     </section>
//   )
// }

// /* ============================================================
//    HOW IT WORKS — 5-step
//    ============================================================ */

// function HowItWorks() {
//   return (
//     <section className="py-16 sm:py-20 bg-slate-50">
//       <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
//         <SectionHeading
//           eyebrow="How it works"
//           title="From 'share your needs' to 'start learning' in 5 steps"
//           desc="Our demo-first matching process gives you confidence before you commit."
//         />
//         <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-5 mt-10">
//           {aeHowItWorks.map((step, i) => (
//             <div
//               key={step.n}
//               style={{ animationDelay: `${i * 60}ms` }}
//               className="bg-white rounded-2xl border border-slate-200 p-5 hover:shadow-md transition-all animate-fade-up"
//             >
//               <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-blue-900 to-slate-900 text-white text-sm font-bold mb-3">
//                 {String(step.n).padStart(2, '0')}
//               </div>
//               <div className="text-3xl mb-2" aria-hidden="true">{step.icon}</div>
//               <h3 className="font-semibold text-slate-900 mb-1.5 text-sm">{step.title}</h3>
//               <p className="text-xs text-slate-600 leading-relaxed">{step.desc}</p>
//             </div>
//           ))}
//         </div>
//         <div className="text-center mt-10">
//           <Link
//             to="/ae/find-tutor"
//             className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-semibold transition-colors shadow-sm"
//           >
//             Get Started — Find My Tutor
//           </Link>
//         </div>
//       </div>
//     </section>
//   )
// }

// /* ============================================================
//    SUBJECTS GRID — Arabic featured
//    ============================================================ */

// function SubjectsGrid() {
//   return (
//     <section className="py-16 sm:py-20 bg-white">
//       <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
//         <SectionHeading
//           eyebrow="Subjects"
//           title="Tutoring for every UAE academic subject"
//           desc="From MOE Arabic to IB Mathematics — verified tutors cover every curriculum track and academic level."
//         />
//         <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 mt-10">
//           {aeSubjects.map((subject) => (
//             <Link
//               key={subject.slug}
//               to={`/ae/subjects?subject=${subject.slug}`}
//               className={`group bg-white rounded-xl border p-4 hover:shadow-md transition-all relative ${
//                 subject.featured
//                   ? 'border-amber-300 hover:border-amber-400 bg-amber-50/40'
//                   : 'border-slate-200 hover:border-blue-300'
//               }`}
//             >
//               {subject.featured && (
//                 <span className="absolute top-2 right-2 text-2xs font-semibold uppercase tracking-wider text-amber-700 bg-amber-100 px-1.5 py-0.5 rounded">
//                   Featured
//                 </span>
//               )}
//               <div className="text-3xl mb-2" aria-hidden="true">{subject.icon}</div>
//               <p className={`font-semibold text-sm transition-colors ${
//                 subject.featured
//                   ? 'text-slate-900 group-hover:text-amber-700'
//                   : 'text-slate-900 group-hover:text-blue-700'
//               }`}>
//                 {subject.label}
//               </p>
//               <p className="text-xs text-slate-500 mt-0.5">{subject.group}</p>
//             </Link>
//           ))}
//         </div>
//         <div className="text-center mt-8">
//           <Link
//             to="/ae/subjects"
//             className="inline-flex items-center gap-1.5 text-sm font-semibold text-blue-900 hover:text-amber-700"
//           >
//             Browse all subjects →
//           </Link>
//         </div>
//       </div>
//     </section>
//   )
// }

// /* ============================================================
//    ACADEMIC LEVELS (renamed from GradeLevels)
//    ============================================================ */

// function AcademicLevels() {
//   const groupIcons = {
//     'Early Years': '🌱',
//     'Primary': '📚',
//     'Middle School': '🎒',
//     'Secondary': '📝',
//     'Examination Years': '🎓',
//   }
//   return (
//     <section className="py-16 sm:py-20 bg-slate-50">
//       <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
//         <SectionHeading
//           eyebrow="Academic Levels"
//           title="Tutoring for every stage of your child's journey"
//           desc="From KG to the IB Diploma, our verified tutors understand each academic level — across MOE, British, American, IB, CBSE, and ICSE curricula."
//         />
//         <div className="grid lg:grid-cols-3 sm:grid-cols-2 gap-6 mt-10">
//           {aeAcademicGroups.map((group) => {
//             const levels = aeAcademicLevels.filter((l) => l.group === group)
//             if (!levels.length) return null
//             return (
//               <div key={group} className="bg-white rounded-2xl border border-slate-200 p-6 hover:shadow-lg transition-shadow">
//                 <div className="flex items-center gap-3 mb-4">
//                   <div className="text-3xl" aria-hidden="true">{groupIcons[group] || '🎓'}</div>
//                   <h3 className="font-display text-xl font-bold text-slate-900">{group}</h3>
//                 </div>
//                 <ul className="space-y-2 mb-5">
//                   {levels.map((lvl) => (
//                     <li key={lvl.slug}>
//                       <Link
//                         to={`/ae/find-tutor?level=${lvl.slug}`}
//                         className="flex items-start justify-between gap-2 p-2 rounded-lg hover:bg-slate-50 transition-colors group"
//                       >
//                         <div>
//                           <p className="text-sm font-medium text-slate-900 group-hover:text-blue-900 transition-colors">{lvl.label}</p>
//                           <p className="text-xs text-slate-500">{lvl.desc}</p>
//                         </div>
//                         <span className="text-slate-300 group-hover:text-amber-600 transition-colors">→</span>
//                       </Link>
//                     </li>
//                   ))}
//                 </ul>
//                 <Link
//                   to={`/ae/find-tutor?group=${encodeURIComponent(group)}`}
//                   className="inline-flex items-center gap-1.5 text-sm font-semibold text-blue-900 hover:text-amber-700"
//                 >
//                   View tutors for {group} →
//                 </Link>
//               </div>
//             )
//           })}
//         </div>
//       </div>
//     </section>
//   )
// }

// /* ============================================================
//    CURRICULUM OPTIONS (NEW — 6 cards: MOE, British, American, IB, CBSE, ICSE)
//    ============================================================ */

// function CurriculumOptions() {
//   return (
//     <section className="py-16 sm:py-20 bg-white">
//       <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
//         <SectionHeading
//           eyebrow="Curriculum Options"
//           title="Six curricula. One trusted platform."
//           desc="The UAE has one of the most diverse curriculum landscapes in the world. Our verified tutors support every major track — choose yours to get matched."
//         />
//         <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 mt-10">
//           {aeCurriculum.map((c) => (
//             <div
//               key={c.slug}
//               className="bg-white rounded-2xl border border-slate-200 p-6 hover:shadow-lg hover:-translate-y-0.5 transition-all"
//             >
//               <div className="text-4xl mb-3" aria-hidden="true">{c.icon}</div>
//               <h3 className="font-display text-lg font-bold text-slate-900 mb-2">{c.label}</h3>
//               <p className="text-sm text-slate-600 leading-relaxed mb-3">{c.desc}</p>
//               <p className="text-xs text-amber-700 font-semibold uppercase tracking-wider mb-2">Key Stages</p>
//               <p className="text-xs text-slate-500 mb-4">{c.keyStages}</p>
//               <div className="flex flex-wrap gap-1.5 mb-4">
//                 {c.subjects.slice(0, 4).map((s) => (
//                   <span key={s} className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 text-xs">{s}</span>
//                 ))}
//                 {c.subjects.length > 4 && (
//                   <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 text-xs">+{c.subjects.length - 4}</span>
//                 )}
//               </div>
//               <Link
//                 to={`/ae/find-tutor?curriculum=${c.slug}`}
//                 className="inline-flex items-center gap-1 text-sm font-semibold text-blue-900 hover:text-amber-700"
//               >
//                 Find a tutor →
//               </Link>
//             </div>
//           ))}
//         </div>
//       </div>
//     </section>
//   )
// }

// /* ============================================================
//    TEST PREP — GCSE, A-Level, IB, CBSE Board, MOE Exam
//    ============================================================ */

// function TestPrep() {
//   return (
//     <section className="py-16 sm:py-20 bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 text-white">
//       <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
//         <div className="text-center mb-10">
//           <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 text-blue-100 text-xs font-semibold uppercase tracking-wider mb-4">
//             <span className="h-1 w-1 rounded-full bg-amber-400" />
//             Test Prep
//           </div>
//           <h2 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-balance">
//             Multi-curriculum exam prep specialists
//           </h2>
//           <p className="mt-4 text-base text-blue-100/80 max-w-2xl mx-auto leading-relaxed">
//             Verified tutors with proven track records across GCSE, A-Level, IB, CBSE Board,
//             and UAE MOE examinations. Demo-first — try before you commit.
//           </p>
//         </div>
//         <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
//           {aeTestPrep.map((p) => (
//             <div
//               key={p.slug}
//               className="bg-white/10 backdrop-blur-sm border border-white/15 rounded-2xl p-6 hover:bg-white/15 transition-colors"
//             >
//               <div className={`inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${p.color} text-white text-2xl mb-4`}>
//                 {p.icon}
//               </div>
//               <h3 className="font-display text-lg font-bold mb-1">{p.name}</h3>
//               <p className="text-xs text-blue-200/80 mb-3">{p.duration}</p>
//               <p className="text-sm text-blue-100/80 leading-relaxed mb-4">{p.desc}</p>
//               <ul className="space-y-1.5">
//                 {p.outcomes.map((o) => (
//                   <li key={o} className="flex items-center gap-2 text-sm text-blue-100/90">
//                     <svg width="12" height="12" viewBox="0 0 12 12" fill="none" className="text-amber-400">
//                       <path d="M2 6l3 3 5-5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
//                     </svg>
//                     {o}
//                   </li>
//                 ))}
//               </ul>
//             </div>
//           ))}
//         </div>
//         <div className="text-center mt-10">
//           <Link
//             to="/ae/find-tutor?goal=test-prep"
//             className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-white text-slate-900 font-semibold hover:bg-amber-50 transition-colors"
//           >
//             Find a Test Prep Tutor →
//           </Link>
//         </div>
//       </div>
//     </section>
//   )
// }

// /* ============================================================
//    LOCATIONS GRID — Abu Dhabi featured
//    ============================================================ */

// function LocationsGrid() {
//   return (
//     <section className="py-16 sm:py-20 bg-white">
//       <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
//         <SectionHeading
//           eyebrow="Locations"
//           title="Online tutoring across the UAE"
//           desc="Sessions fit your schedule — from Abu Dhabi, our featured launch location, to Dubai, Sharjah, Al Ain, and all other Emirates."
//         />
//         <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 mt-10">
//           {aeLocations.map((loc) => (
//             <Link
//               key={loc.slug}
//               to={`/ae/locations?area=${loc.slug}`}
//               className={`group rounded-xl border p-4 transition-all relative ${
//                 loc.featured
//                   ? 'bg-amber-50/60 border-amber-300 hover:border-amber-400 hover:shadow-md'
//                   : 'bg-slate-50 hover:bg-blue-50 border-slate-200 hover:border-blue-300'
//               }`}
//             >
//               {loc.featured && (
//                 <span className="absolute -top-2 left-3 text-2xs font-semibold uppercase tracking-wider text-amber-800 bg-amber-100 border border-amber-200 px-1.5 py-0.5 rounded">
//                   ★ Featured
//                 </span>
//               )}
//               <div className="flex items-center justify-between mb-1 mt-1">
//                 <p className={`font-semibold text-sm transition-colors ${
//                   loc.featured
//                     ? 'text-slate-900 group-hover:text-amber-700'
//                     : 'text-slate-900 group-hover:text-blue-700'
//                 }`}>
//                   {loc.label}
//                 </p>
//                 {loc.primary && !loc.featured && (
//                   <span className="text-2xs font-semibold uppercase text-blue-900">Top</span>
//                 )}
//               </div>
//               <p className="text-xs text-slate-500">{loc.region}</p>
//             </Link>
//           ))}
//         </div>
//         <div className="text-center mt-8">
//           <Link
//             to="/ae/locations"
//             className="inline-flex items-center gap-1.5 text-sm font-semibold text-blue-900 hover:text-amber-700"
//           >
//             View all locations →
//           </Link>
//         </div>
//       </div>
//     </section>
//   )
// }

// /* ============================================================
//    VERIFIED TUTORS — Global pool (clearly labelled)
//    ============================================================ */

// function VerifiedTutors() {
//   // Per spec §5 + the user's clarification: reuse India's verified tutors
//   // globally with clear "Online Tutors" labeling — no fabricated identities.
//   const tutors = (expertTeachers || []).slice(0, 6)
//   return (
//     <section className="py-16 sm:py-20 bg-slate-50">
//       <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
//         <SectionHeading
//           eyebrow="Verified Tutors"
//           title="Meet a few of our verified online tutors"
//           desc="Our global pool of expert tutors is available online to UAE families. Each tutor is background-checked, credentials-verified, and demo-evaluated."
//         />
//         <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 mt-10">
//           {tutors.map((t) => (
//             <div
//               key={t.id}
//               className="bg-white rounded-2xl border border-slate-200 p-6 hover:shadow-lg hover:-translate-y-0.5 transition-all"
//             >
//               <div className={`flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br ${t.gradient || 'from-blue-900 to-slate-900'} text-white text-xl font-bold mb-4`}>
//                 {t.initials || t.name.charAt(0)}
//               </div>
//               <div className="flex items-center gap-2 mb-1">
//                 <h3 className="font-display text-base font-bold text-slate-900">{t.name}</h3>
//                 <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-2xs font-semibold">
//                   <span className="h-1 w-1 rounded-full bg-emerald-600" />
//                   Verified
//                 </span>
//               </div>
//               <p className="text-xs text-slate-500 mb-3">{t.qualification}</p>
//               <div className="flex flex-wrap gap-1.5 mb-3">
//                 {(t.subjects || []).slice(0, 3).map((s) => (
//                   <span key={s} className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 text-xs">
//                     {s}
//                   </span>
//                 ))}
//               </div>
//               <div className="grid grid-cols-3 gap-2 text-center pt-3 border-t border-slate-100">
//                 <Stat label="Rating" value={t.rating ? `★ ${t.rating}` : '★ New'} />
//                 <Stat label="Students" value={t.students || 0} />
//                 <Stat label="Years" value={t.experience || '—'} />
//               </div>
//             </div>
//           ))}
//         </div>
//         <div className="mt-6 p-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-sm">
//           <p>
//             <strong>Online tutors available worldwide.</strong> The tutors above are
//             part of Srijee Tutor's global verified pool, available online to UAE families.
//             Emirates-specific in-person availability depends on your location — confirm
//             with your educational consultant during the free consultation.
//           </p>
//         </div>
//       </div>
//     </section>
//   )
// }

// function Stat({ label, value }) {
//   return (
//     <div>
//       <p className="text-sm font-bold text-slate-900 tabular-nums">{value}</p>
//       <p className="text-2xs text-slate-500">{label}</p>
//     </div>
//   )
// }

// /* ============================================================
//    TESTIMONIALS — clearly marked Demo
//    ============================================================ */

// function Testimonials() {
//   return (
//     <section className="py-16 sm:py-20 bg-white">
//       <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
//         <SectionHeading
//           eyebrow="Testimonials"
//           title="What UAE families say about us"
//           desc="Honest feedback from UAE families. Currently shown as demo content — replace with verified UAE testimonials before public launch."
//         />
//         <div className="grid lg:grid-cols-3 gap-5 mt-10">
//           {aeTestimonials.map((t) => (
//             <div
//               key={t.id}
//               className="bg-white rounded-2xl border border-slate-200 p-6 relative"
//             >
//               <span className="absolute top-4 right-4 inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 text-2xs font-semibold uppercase tracking-wider">
//                 Demo
//               </span>
//               <div className="flex items-center gap-1 text-amber-400 mb-3">
//                 {[1, 2, 3, 4, 5].map((i) => (
//                   <svg key={i} width="14" height="14" viewBox="0 0 14 14" fill="currentColor">
//                     <path d="M7 1l1.6 4.3L13 6l-3.4 2.7L11 13 7 10.5 3 13l1.4-4.3L1 6l4.4-0.7z" />
//                   </svg>
//                 ))}
//               </div>
//               <p className="text-sm text-slate-700 leading-relaxed italic mb-4">
//                 "{t.quote}"
//               </p>
//               <div className="flex items-center gap-3 pt-4 border-t border-slate-100">
//                 <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-blue-900 to-slate-900 text-white font-bold text-sm">
//                   {t.name.split(' ').slice(-2).map((p) => p[0]).join('')}
//                 </div>
//                 <div>
//                   <p className="text-sm font-semibold text-slate-900">{t.name}</p>
//                   <p className="text-xs text-slate-500">{t.role} · {t.location}</p>
//                 </div>
//               </div>
//             </div>
//           ))}
//         </div>
//       </div>
//     </section>
//   )
// }

// /* ============================================================
//    FAQ
//    ============================================================ */

// function FAQ() {
//   const [open, setOpen] = useState(0)
//   return (
//     <section className="py-16 sm:py-20 bg-slate-50">
//       <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
//         <SectionHeading
//           eyebrow="FAQ"
//           title="Common questions from UAE families"
//           desc="Everything you need to know before getting started."
//         />
//         <div className="mt-10 space-y-3">
//           {aeFaqs.map((item, i) => {
//             const isOpen = open === i
//             return (
//               <div key={i} className="bg-white rounded-xl border border-slate-200 overflow-hidden">
//                 <button
//                   type="button"
//                   onClick={() => setOpen(isOpen ? -1 : i)}
//                   className="w-full flex items-center justify-between gap-4 p-5 text-left hover:bg-slate-50 transition-colors"
//                   aria-expanded={isOpen}
//                 >
//                   <span className="font-semibold text-slate-900 text-sm">{item.q}</span>
//                   <span className={`flex-none flex h-7 w-7 items-center justify-center rounded-full text-sm transition-all ${isOpen ? 'bg-blue-900 text-white rotate-45' : 'bg-slate-100 text-slate-600'}`}>
//                     +
//                   </span>
//                 </button>
//                 {isOpen && (
//                   <div className="px-5 pb-5 pt-0 text-sm text-slate-700 leading-relaxed animate-fade-in">
//                     {item.a}
//                   </div>
//                 )}
//               </div>
//             )
//           })}
//         </div>
//       </div>
//     </section>
//   )
// }

// /* ============================================================
//    FINAL CTA
//    ============================================================ */

// function FinalCTA() {
//   return (
//     <section className="py-16 sm:py-20 bg-gradient-to-br from-blue-900 via-blue-950 to-slate-900 text-white">
//       <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
//         <h2 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-balance">
//           Ready to find the right tutor for your child?
//         </h2>
//         <p className="mt-4 text-base sm:text-lg text-blue-100/90 max-w-2xl mx-auto leading-relaxed">
//           Get matched with 2–3 verified UAE-aligned tutors in 3 minutes. Free educational
//           consultant consultation. Free demo class. No commitment until you're ready.
//         </p>
//         <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
//           <Link
//             to="/ae/find-tutor"
//             className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-white text-slate-900 font-semibold hover:bg-amber-50 transition-colors shadow-lg"
//           >
//             Find My Tutor →
//           </Link>
//           <a
//             href={`tel:${SITE.phoneHref}`}
//             className="inline-flex items-center gap-2 px-6 py-3 rounded-xl border border-white/30 text-white hover:bg-white/10 transition-colors"
//           >
//             📞 {SITE.phoneDisplay}
//           </a>
//           <Link
//             to="/ae/contact"
//             className="inline-flex items-center gap-2 px-6 py-3 rounded-xl text-blue-100 hover:text-amber-300 transition-colors"
//           >
//             Free Consultation →
//           </Link>
//         </div>
//       </div>
//     </section>
//   )
// }

// /* ============================================================
//    Shared sub-component
//    ============================================================ */

// function SectionHeading({ eyebrow, title, desc }) {
//   return (
//     <div className="text-center">
//       <p className="text-xs font-semibold uppercase tracking-wider text-amber-700 mb-3">{eyebrow}</p>
//       <h2 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 text-balance">
//         {title}
//       </h2>
//       {desc && (
//         <p className="mt-4 text-base text-slate-600 max-w-2xl mx-auto leading-relaxed text-pretty">
//           {desc}
//         </p>
//       )}
//     </div>
//   )
// }
import React, { useState, useEffect, useRef } from 'react'
import { Link } from 'react-router-dom'
import RegionSeo from '../../us/components/RegionSeo.jsx'
import {
  aeAcademicLevels,
  aeAcademicGroups,
  aeCurriculum,
  aeSubjects,
  aeLocations,
  aeTestPrep,
  aeTestimonials,
  aeHowItWorks,
  aeWhyChooseUs,
  aeFaqs,
} from '../data/aeContent.js'
import { SITE } from '../../../config/site.js'
import { expertTeachers } from '../../../data/expertTeachers.js'

/**
 * UAEHome — the homepage of the United Arab Emirates regional frontend.
 *
 * Section composition:
 *   Hero (with embedded "Find My Tutor" mini-form: Curriculum + Academic Level + Subject) →
 *   TrustStrip →
 *   WhyChooseUs (6-card grid — UAE-specific) →
 *   HowItWorks (5-step — Educational Consultant terminology) →
 *   Subjects (popular subjects grid — Arabic featured) →
 *   AcademicLevels (KG, Primary, Middle, Secondary, Examination Years) →
 *   CurriculumOptions (NEW — 6 cards: MOE, British, American, IB, CBSE, ICSE) →
 *   TestPrep (GCSE, A-Level, IB, CBSE Board, MOE Exam) →
 *   Locations (Abu Dhabi primary) →
 *   Tutors (verified online tutors — global pool) →
 *   Testimonials (clearly marked Demo) →
 *   FAQ (UAE-specific) →
 *   FinalCTA
 *
 * Per spec §9: Premium navy/white design, subtle gold accents (NOT primary fills).
 * Currency AED. British English spelling throughout.
 * Initial marketing focus: Abu Dhabi.
 */

const HERO_STATS = [
  { label: 'Verified Tutors', value: '100', suffix: '+' },
  { label: 'Multi-Curriculum Support', value: '6', suffix: ' curricula' },
  { label: 'Across the UAE', value: '5', suffix: ' Emirates' },
  { label: 'Years of Tutoring Excellence', value: SITE.stats?.yearsExperience || '13', suffix: '' },
]

const TRUST_STRIP = [
  { label: 'Background-checked tutors', icon: '✓' },
  { label: 'Multi-curriculum support', icon: '🏛️' },
  { label: 'Free demo class first', icon: '🎬' },
  { label: 'Dedicated UAE educational consultant', icon: '🤝' },
]

export default function UAEHome() {
  return (
    <>
      <RegionSeo path="/ae" />
      <Hero />
      <TrustStrip />
      <WhyChooseUs />
      <HowItWorks />
      <SubjectsGrid />
      <AcademicLevels />
      <CurriculumOptions />
      <TestPrep />
      <LocationsGrid />
      <VerifiedTutors />
      <Testimonials />
      <FAQ />
      <FinalCTA />
    </>
  )
}

/* ============================================================
   HERO — deep navy night sky, two-column, embedded mini-form
   ============================================================ */

function Hero() {
  const [form, setForm] = useState({ curriculum: '', level: '', subject: '' })

  const handleQuickSubmit = (e) => {
    e.preventDefault()

    const params = new URLSearchParams()

    if (form.curriculum) params.set('curriculum', form.curriculum)
    if (form.level) params.set('level', form.level)
    if (form.subject) params.set('subject', form.subject)

    window.location.href = `/ae/find-tutor?${params.toString()}`
  }

  return (
    <section
      className="relative min-h-[680px] overflow-hidden bg-cover bg-center bg-no-repeat text-white sm:min-h-[720px] lg:min-h-[760px]"
      style={{
        backgroundImage: "url('/images/regions/burj-khalifa-hero.jpg')",
      }}
    >
      {/* Left-side overlay — dark only where text lives, fades to transparent centre */}
      <div
        className="absolute inset-0 bg-gradient-to-r from-[#04132f]/92 via-[#071d42]/30 to-transparent"
        aria-hidden="true"
      />

      {/* Bottom fade for clean trust-strip transition */}
      <div
        className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-[#061735]/70 via-[#061735]/20 to-transparent"
        aria-hidden="true"
      />

      {/* Subtle UAE-gold atmospheric glow */}
      <div
        className="pointer-events-none absolute right-8 top-1/3 h-80 w-80 rounded-full bg-amber-400/8 blur-3xl"
        aria-hidden="true"
      />

      <div className="relative flex min-h-[680px] items-center sm:min-h-[720px] lg:min-h-[760px]">
        <div className="mx-auto w-full max-w-7xl px-4 py-4 sm:px-6 sm:py-4 lg:px-8 lg:py-4">
          {/* lg:grid-cols-[1.45fr_0.8fr] — wider left so form sits on the far right */}
          <div className="grid items-center gap-10 lg:grid-cols-[1.45fr_0.8fr] lg:gap-12">
            {/* Left: copy */}
            <div className="max-w-3xl">


              <h1 className="font-display text-4xl font-bold leading-[1.05] tracking-tight text-white text-balance sm:text-5xl lg:text-6xl xl:text-7xl">
                Find trusted tutors for your{' '}
                <span className="bg-gradient-to-r from-amber-300 via-amber-400 to-yellow-300 bg-clip-text text-transparent">
                  curriculum and goals.
                </span>
              </h1>

              <p className="mt-6 max-w-2xl text-base leading-relaxed text-white/90 sm:text-lg lg:text-xl">
                Verified online tutors across MOE, British, American, IB, CBSE, and ICSE
                curricula. Personalised, premium, and always demo-first. From Abu Dhabi to
                Dubai — across all the Emirates.
              </p>

              {/* CTA row */}
              <div className="mt-8 flex flex-wrap items-center gap-3">
                <Link
                  to="/ae/find-tutor"
                  className="inline-flex items-center gap-2 rounded-xl bg-[#1d4ed8] px-6 py-3.5 font-semibold text-white shadow-xl shadow-blue-950/40 transition-all hover:-translate-y-0.5 hover:bg-[#2563eb] hover:shadow-2xl"
                >
                  Find My Tutor →
                </Link>

                <a
                  href={`tel:${SITE.phoneHref}`}
                  className="inline-flex items-center gap-2 rounded-xl border border-white/30 bg-white/10 px-6 py-3.5 text-white backdrop-blur-md transition-all hover:bg-white/20"
                >
                  📞 {SITE.phoneDisplay}
                </a>
              </div>

              {/* Stats */}
              <div className="mt-10 grid grid-cols-2 gap-x-5 gap-y-7 sm:grid-cols-4 sm:gap-6">
                {HERO_STATS.map((s) => (
                  <StatBlock key={s.label} stat={s} />
                ))}
              </div>
            </div>

            {/* Right: quick-match form */}
            <div className="rounded-3xl border border-white/25 bg-white/10 p-6 text-white shadow-[0_25px_80px_rgba(0,0,0,0.28)] backdrop-blur-xl sm:p-8">
              <div className="mb-3 inline-flex items-center gap-1.5 rounded-full bg-amber-50 px-2.5 py-1 text-xs font-semibold text-amber-800">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-amber-600" />
                Quick match — 3 minutes
              </div>

              <h2 className="font-display mb-1 text-2xl font-bold text-slate-900">
                Tell us what you need
              </h2>

              <p className="mb-5 text-sm leading-relaxed text-white/75">
                Get matched with 2–3 verified tutors in your curriculum and academic level.
              </p>

              <form onSubmit={handleQuickSubmit} className="space-y-4">
                <div>
                  <label
                    htmlFor="uae-hero-curriculum"
                    className="mb-1.5 block text-xs font-semibold text-white/75"
                  >
                    Curriculum
                  </label>

                  <select
                    id="uae-hero-curriculum"
                    value={form.curriculum}
                    onChange={(e) =>
                      setForm((f) => ({ ...f, curriculum: e.target.value }))
                    }
                    className="w-full rounded-xl border border-slate-300 bg-white px-3.5 py-3 text-sm text-slate-800 outline-none transition focus:border-blue-700 focus:ring-2 focus:ring-blue-200"
                  >
                    <option value="">Select a curriculum</option>
                    <option value="uae-moe">UAE / MOE Curriculum</option>
                    <option value="british">British Curriculum</option>
                    <option value="american">American Curriculum</option>
                    <option value="ib">IB Curriculum</option>
                    <option value="cbse">CBSE (Indian)</option>
                    <option value="icse">ICSE (Indian)</option>
                  </select>
                </div>

                <div>
                  <label
                    htmlFor="uae-hero-level"
                    className="mb-1.5 block text-xs font-semibold text-white/75"
                  >
                    Academic Level
                  </label>

                  <select
                    id="uae-hero-level"
                    value={form.level}
                    onChange={(e) =>
                      setForm((f) => ({ ...f, level: e.target.value }))
                    }
                    className="w-full rounded-xl border border-slate-300 bg-white px-3.5 py-3 text-sm text-slate-800 outline-none transition focus:border-blue-700 focus:ring-2 focus:ring-blue-200"
                  >
                    <option value="">Select a level</option>

                    <optgroup label="Early Years">
                      <option value="kg">KG (Kindergarten)</option>
                    </optgroup>

                    <optgroup label="Primary">
                      <option value="primary">Primary School</option>
                    </optgroup>

                    <optgroup label="Middle">
                      <option value="middle-school">Middle School</option>
                      <option value="secondary">Secondary</option>
                    </optgroup>

                    <optgroup label="Examination Years">
                      <option value="gcse">GCSE</option>
                      <option value="igcse">IGCSE</option>
                      <option value="a-level">A-Level</option>
                      <option value="ib">IB Diploma</option>
                    </optgroup>
                  </select>
                </div>

                <div>
                  <label
                    htmlFor="uae-hero-subject"
                    className="mb-1.5 block text-xs font-semibold text-white/75"
                  >
                    Subject
                  </label>

                  <select
                    id="uae-hero-subject"
                    value={form.subject}
                    onChange={(e) =>
                      setForm((f) => ({ ...f, subject: e.target.value }))
                    }
                    className="w-full rounded-xl border border-slate-300 bg-white px-3.5 py-3 text-sm text-slate-800 outline-none transition focus:border-blue-700 focus:ring-2 focus:ring-blue-200"
                  >
                    <option value="">Select a subject</option>

                    {aeSubjects.map((s) => (
                      <option key={s.slug} value={s.slug}>
                        {s.label}
                      </option>
                    ))}
                  </select>
                </div>

                <button
                  type="submit"
                  className="w-full rounded-xl bg-[#1d4ed8] px-4 py-3.5 text-sm font-semibold text-white shadow-lg transition-all hover:bg-[#2563eb] hover:shadow-xl"
                >
                  Find My Tutor →
                </button>

                <p className="text-center text-xs leading-relaxed text-white/75">
                  No payment required. Free educational consultant consultation + free
                  demo class.
                </p>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

function StatBlock({ stat }) {
  const ref = useRef(null)
  const [val, setVal] = useState(0)
  const [done, setDone] = useState(false)

  useEffect(() => {
    if (!ref.current || done) return

    const target = parseFloat(String(stat.value).replace(/[^\d.]/g, '')) || 0

    if (!target || !isFinite(target)) {
      setVal(stat.value)
      setDone(true)
      return
    }

    const obs = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          const start = performance.now()
          const dur = 1400

          const tick = (now) => {
            const t = Math.min(1, (now - start) / dur)
            const eased = 1 - Math.pow(1 - t, 3)
            const current = target * eased

            setVal(
              stat.value % 1 !== 0
                ? current.toFixed(1)
                : Math.round(current).toLocaleString('en-GB')
            )

            if (t < 1) {
              requestAnimationFrame(tick)
            } else {
              setVal(stat.value)
            }
          }

          requestAnimationFrame(tick)
          setDone(true)
        }
      },
      { threshold: 0.4 }
    )

    obs.observe(ref.current)

    return () => obs.disconnect()
  }, [stat.value, done])

  return (
    // <div ref={ref} className="text-center sm:text-left">
    //   <div className="font-display text-2xl font-bold tabular-nums text-white sm:text-3xl">
    //     {val}
    //     <span className="text-amber-300">{stat.suffix}</span>
    //   </div>
    <div ref={ref} className="text-center sm:text-left">
  <div className="font-display text-3xl font-bold tabular-nums text-white">
    {val}
    <span className="mt-1 text-xs text-white">{stat.suffix}</span>
  </div>

  <div className="mt-1 text-xs text-white/75">
    {stat.label}
  </div>

    </div>
  )
}

/* ============================================================
   TRUST STRIP
   ============================================================ */

function TrustStrip() {
  return (
    <section className="bg-blue-50 border-y border-blue-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {TRUST_STRIP.map((item) => (
            <div key={item.label} className="flex items-center gap-3">
              <span className="flex h-9 w-9 items-center justify-center rounded-full bg-white text-blue-900 shadow-sm text-sm font-bold">
                {item.icon}
              </span>
              <span className="text-sm font-medium text-slate-700">{item.label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ============================================================
   WHY CHOOSE US
   ============================================================ */

function WhyChooseUs() {
  return (
    <section className="py-16 sm:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Why families choose us"
          title="Built for UAE families, designed for every curriculum"
          desc="Srijee Tutor brings a global tutoring methodology to the UAE — adapted for MOE, British, American, IB, CBSE, and ICSE curricula, with native Arabic support."
        />
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 mt-10">
          {aeWhyChooseUs.map((feature, i) => (
            <div
              key={feature.title}
              style={{ animationDelay: `${i * 60}ms` }}
              className="bg-white rounded-2xl border border-slate-200 p-6 hover:shadow-lg hover:-translate-y-0.5 transition-all animate-fade-up"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-blue-50 text-blue-900 text-xl mb-4">
                {feature.icon}
              </div>
              <h3 className="font-display text-lg font-bold text-slate-900 mb-2">
                {feature.title}
              </h3>
              <p className="text-sm text-slate-600 leading-relaxed">{feature.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ============================================================
   HOW IT WORKS — 5-step
   ============================================================ */

function HowItWorks() {
  return (
    <section className="py-16 sm:py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="How it works"
          title="From 'share your needs' to 'start learning' in 5 steps"
          desc="Our demo-first matching process gives you confidence before you commit."
        />
        <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-5 mt-10">
          {aeHowItWorks.map((step, i) => (
            <div
              key={step.n}
              style={{ animationDelay: `${i * 60}ms` }}
              className="bg-white rounded-2xl border border-slate-200 p-5 hover:shadow-md transition-all animate-fade-up"
            >
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-blue-900 to-slate-900 text-white text-sm font-bold mb-3">
                {String(step.n).padStart(2, '0')}
              </div>
              <div className="text-3xl mb-2" aria-hidden="true">{step.icon}</div>
              <h3 className="font-semibold text-slate-900 mb-1.5 text-sm">{step.title}</h3>
              <p className="text-xs text-slate-600 leading-relaxed">{step.desc}</p>
            </div>
          ))}
        </div>
        <div className="text-center mt-10">
          <Link
            to="/ae/find-tutor"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-semibold transition-colors shadow-sm"
          >
            Get Started — Find My Tutor
          </Link>
        </div>
      </div>
    </section>
  )
}

/* ============================================================
   SUBJECTS GRID — Arabic featured
   ============================================================ */

function SubjectsGrid() {
  return (
    <section className="py-16 sm:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Subjects"
          title="Tutoring for every UAE academic subject"
          desc="From MOE Arabic to IB Mathematics — verified tutors cover every curriculum track and academic level."
        />
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 mt-10">
          {aeSubjects.map((subject) => (
            <Link
              key={subject.slug}
              to={`/ae/subjects?subject=${subject.slug}`}
              className={`group bg-white rounded-xl border p-4 hover:shadow-md transition-all relative ${
                subject.featured
                  ? 'border-amber-300 hover:border-amber-400 bg-amber-50/40'
                  : 'border-slate-200 hover:border-blue-300'
              }`}
            >
              {subject.featured && (
                <span className="absolute top-2 right-2 text-2xs font-semibold uppercase tracking-wider text-amber-700 bg-amber-100 px-1.5 py-0.5 rounded">
                  Featured
                </span>
              )}
              <div className="text-3xl mb-2" aria-hidden="true">{subject.icon}</div>
              <p className={`font-semibold text-sm transition-colors ${
                subject.featured
                  ? 'text-slate-900 group-hover:text-amber-700'
                  : 'text-slate-900 group-hover:text-blue-700'
              }`}>
                {subject.label}
              </p>
              <p className="text-xs text-slate-500 mt-0.5">{subject.group}</p>
            </Link>
          ))}
        </div>
        <div className="text-center mt-8">
          <Link
            to="/ae/subjects"
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-blue-900 hover:text-amber-700"
          >
            Browse all subjects →
          </Link>
        </div>
      </div>
    </section>
  )
}

/* ============================================================
   ACADEMIC LEVELS (renamed from GradeLevels)
   ============================================================ */

function AcademicLevels() {
  const groupIcons = {
    'Early Years': '🌱',
    'Primary': '📚',
    'Middle School': '🎒',
    'Secondary': '📝',
    'Examination Years': '🎓',
  }
  return (
    <section className="py-16 sm:py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Academic Levels"
          title="Tutoring for every stage of your child's journey"
          desc="From KG to the IB Diploma, our verified tutors understand each academic level — across MOE, British, American, IB, CBSE, and ICSE curricula."
        />
        <div className="grid lg:grid-cols-3 sm:grid-cols-2 gap-6 mt-10">
          {aeAcademicGroups.map((group) => {
            const levels = aeAcademicLevels.filter((l) => l.group === group)
            if (!levels.length) return null
            return (
              <div key={group} className="bg-white rounded-2xl border border-slate-200 p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center gap-3 mb-4">
                  <div className="text-3xl" aria-hidden="true">{groupIcons[group] || '🎓'}</div>
                  <h3 className="font-display text-xl font-bold text-slate-900">{group}</h3>
                </div>
                <ul className="space-y-2 mb-5">
                  {levels.map((lvl) => (
                    <li key={lvl.slug}>
                      <Link
                        to={`/ae/find-tutor?level=${lvl.slug}`}
                        className="flex items-start justify-between gap-2 p-2 rounded-lg hover:bg-slate-50 transition-colors group"
                      >
                        <div>
                          <p className="text-sm font-medium text-slate-900 group-hover:text-blue-900 transition-colors">{lvl.label}</p>
                          <p className="text-xs text-slate-500">{lvl.desc}</p>
                        </div>
                        <span className="text-slate-300 group-hover:text-amber-600 transition-colors">→</span>
                      </Link>
                    </li>
                  ))}
                </ul>
                <Link
                  to={`/ae/find-tutor?group=${encodeURIComponent(group)}`}
                  className="inline-flex items-center gap-1.5 text-sm font-semibold text-blue-900 hover:text-amber-700"
                >
                  View tutors for {group} →
                </Link>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}

/* ============================================================
   CURRICULUM OPTIONS (NEW — 6 cards: MOE, British, American, IB, CBSE, ICSE)
   ============================================================ */

function CurriculumOptions() {
  return (
    <section className="py-16 sm:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Curriculum Options"
          title="Six curricula. One trusted platform."
          desc="The UAE has one of the most diverse curriculum landscapes in the world. Our verified tutors support every major track — choose yours to get matched."
        />
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 mt-10">
          {aeCurriculum.map((c) => (
            <div
              key={c.slug}
              className="bg-white rounded-2xl border border-slate-200 p-6 hover:shadow-lg hover:-translate-y-0.5 transition-all"
            >
              <div className="text-4xl mb-3" aria-hidden="true">{c.icon}</div>
              <h3 className="font-display text-lg font-bold text-slate-900 mb-2">{c.label}</h3>
              <p className="text-sm text-slate-600 leading-relaxed mb-3">{c.desc}</p>
              <p className="text-xs text-amber-700 font-semibold uppercase tracking-wider mb-2">Key Stages</p>
              <p className="text-xs text-slate-500 mb-4">{c.keyStages}</p>
              <div className="flex flex-wrap gap-1.5 mb-4">
                {c.subjects.slice(0, 4).map((s) => (
                  <span key={s} className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 text-xs">{s}</span>
                ))}
                {c.subjects.length > 4 && (
                  <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 text-xs">+{c.subjects.length - 4}</span>
                )}
              </div>
              <Link
                to={`/ae/find-tutor?curriculum=${c.slug}`}
                className="inline-flex items-center gap-1 text-sm font-semibold text-blue-900 hover:text-amber-700"
              >
                Find a tutor →
              </Link>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ============================================================
   TEST PREP — GCSE, A-Level, IB, CBSE Board, MOE Exam
   ============================================================ */

function TestPrep() {
  return (
    <section className="py-16 sm:py-20 bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 text-blue-100 text-xs font-semibold uppercase tracking-wider mb-4">
            <span className="h-1 w-1 rounded-full bg-amber-400" />
            Test Prep
          </div>
          <h2 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-balance">
            Multi-curriculum exam prep specialists
          </h2>
          <p className="mt-4 text-base text-blue-100/80 max-w-2xl mx-auto leading-relaxed">
            Verified tutors with proven track records across GCSE, A-Level, IB, CBSE Board,
            and UAE MOE examinations. Demo-first — try before you commit.
          </p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {aeTestPrep.map((p) => (
            <div
              key={p.slug}
              className="bg-white/10 backdrop-blur-sm border border-white/15 rounded-2xl p-6 hover:bg-white/15 transition-colors"
            >
              <div className={`inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${p.color} text-white text-2xl mb-4`}>
                {p.icon}
              </div>
              <h3 className="font-display text-lg font-bold mb-1">{p.name}</h3>
              <p className="text-xs text-blue-200/80 mb-3">{p.duration}</p>
              <p className="text-sm text-blue-100/80 leading-relaxed mb-4">{p.desc}</p>
              <ul className="space-y-1.5">
                {p.outcomes.map((o) => (
                  <li key={o} className="flex items-center gap-2 text-sm text-blue-100/90">
                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" className="text-amber-400">
                      <path d="M2 6l3 3 5-5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                    {o}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="text-center mt-10">
          <Link
            to="/ae/find-tutor?goal=test-prep"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-white text-slate-900 font-semibold hover:bg-amber-50 transition-colors"
          >
            Find a Test Prep Tutor →
          </Link>
        </div>
      </div>
    </section>
  )
}

/* ============================================================
   LOCATIONS GRID — Abu Dhabi featured
   ============================================================ */

function LocationsGrid() {
  return (
    <section className="py-16 sm:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Locations"
          title="Online tutoring across the UAE"
          desc="Sessions fit your schedule — from Abu Dhabi, our featured launch location, to Dubai, Sharjah, Al Ain, and all other Emirates."
        />
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 mt-10">
          {aeLocations.map((loc) => (
            <Link
              key={loc.slug}
              to={`/ae/locations?area=${loc.slug}`}
              className={`group rounded-xl border p-4 transition-all relative ${
                loc.featured
                  ? 'bg-amber-50/60 border-amber-300 hover:border-amber-400 hover:shadow-md'
                  : 'bg-slate-50 hover:bg-blue-50 border-slate-200 hover:border-blue-300'
              }`}
            >
              {loc.featured && (
                <span className="absolute -top-2 left-3 text-2xs font-semibold uppercase tracking-wider text-amber-800 bg-amber-100 border border-amber-200 px-1.5 py-0.5 rounded">
                  ★ Featured
                </span>
              )}
              <div className="flex items-center justify-between mb-1 mt-1">
                <p className={`font-semibold text-sm transition-colors ${
                  loc.featured
                    ? 'text-slate-900 group-hover:text-amber-700'
                    : 'text-slate-900 group-hover:text-blue-700'
                }`}>
                  {loc.label}
                </p>
                {loc.primary && !loc.featured && (
                  <span className="text-2xs font-semibold uppercase text-blue-900">Top</span>
                )}
              </div>
              <p className="text-xs text-slate-500">{loc.region}</p>
            </Link>
          ))}
        </div>
        <div className="text-center mt-8">
          <Link
            to="/ae/locations"
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-blue-900 hover:text-amber-700"
          >
            View all locations →
          </Link>
        </div>
      </div>
    </section>
  )
}

/* ============================================================
   VERIFIED TUTORS — Global pool (clearly labelled)
   ============================================================ */

function VerifiedTutors() {
  // Per spec §5 + the user's clarification: reuse India's verified tutors
  // globally with clear "Online Tutors" labeling — no fabricated identities.
  const tutors = (expertTeachers || []).slice(0, 6)
  return (
    <section className="py-16 sm:py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Verified Tutors"
          title="Meet a few of our verified online tutors"
          desc="Our global pool of expert tutors is available online to UAE families. Each tutor is background-checked, credentials-verified, and demo-evaluated."
        />
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 mt-10">
          {tutors.map((t) => (
            <div
              key={t.id}
              className="bg-white rounded-2xl border border-slate-200 p-6 hover:shadow-lg hover:-translate-y-0.5 transition-all"
            >
              <div className={`flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br ${t.gradient || 'from-blue-900 to-slate-900'} text-white text-xl font-bold mb-4`}>
                {t.initials || t.name.charAt(0)}
              </div>
              <div className="flex items-center gap-2 mb-1">
                <h3 className="font-display text-base font-bold text-slate-900">{t.name}</h3>
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-2xs font-semibold">
                  <span className="h-1 w-1 rounded-full bg-emerald-600" />
                  Verified
                </span>
              </div>
              <p className="text-xs text-slate-500 mb-3">{t.qualification}</p>
              <div className="flex flex-wrap gap-1.5 mb-3">
                {(t.subjects || []).slice(0, 3).map((s) => (
                  <span key={s} className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 text-xs">
                    {s}
                  </span>
                ))}
              </div>
              <div className="grid grid-cols-3 gap-2 text-center pt-3 border-t border-slate-100">
                <Stat label="Rating" value={t.rating ? `★ ${t.rating}` : '★ New'} />
                <Stat label="Students" value={t.students || 0} />
                <Stat label="Years" value={t.experience || '—'} />
              </div>
            </div>
          ))}
        </div>
        <div className="mt-6 p-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-sm">
          <p>
            <strong>Online tutors available worldwide.</strong> The tutors above are
            part of Srijee Tutor's global verified pool, available online to UAE families.
            Emirates-specific in-person availability depends on your location — confirm
            with your educational consultant during the free consultation.
          </p>
        </div>
      </div>
    </section>
  )
}

function Stat({ label, value }) {
  return (
    <div>
      <p className="text-sm font-bold text-slate-900 tabular-nums">{value}</p>
      <p className="text-2xs text-slate-500">{label}</p>
    </div>
  )
}

/* ============================================================
   TESTIMONIALS — clearly marked Demo
   ============================================================ */

function Testimonials() {
  return (
    <section className="py-16 sm:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Testimonials"
          title="What UAE families say about us"
          desc="Honest feedback from UAE families. Currently shown as demo content — replace with verified UAE testimonials before public launch."
        />
        <div className="grid lg:grid-cols-3 gap-5 mt-10">
          {aeTestimonials.map((t) => (
            <div
              key={t.id}
              className="bg-white rounded-2xl border border-slate-200 p-6 relative"
            >
              <span className="absolute top-4 right-4 inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 text-2xs font-semibold uppercase tracking-wider">
                Demo
              </span>
              <div className="flex items-center gap-1 text-amber-400 mb-3">
                {[1, 2, 3, 4, 5].map((i) => (
                  <svg key={i} width="14" height="14" viewBox="0 0 14 14" fill="currentColor">
                    <path d="M7 1l1.6 4.3L13 6l-3.4 2.7L11 13 7 10.5 3 13l1.4-4.3L1 6l4.4-0.7z" />
                  </svg>
                ))}
              </div>
              <p className="text-sm text-slate-700 leading-relaxed italic mb-4">
                "{t.quote}"
              </p>
              <div className="flex items-center gap-3 pt-4 border-t border-slate-100">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-blue-900 to-slate-900 text-white font-bold text-sm">
                  {t.name.split(' ').slice(-2).map((p) => p[0]).join('')}
                </div>
                <div>
                  <p className="text-sm font-semibold text-slate-900">{t.name}</p>
                  <p className="text-xs text-slate-500">{t.role} · {t.location}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ============================================================
   FAQ
   ============================================================ */

function FAQ() {
  const [open, setOpen] = useState(0)
  return (
    <section className="py-16 sm:py-20 bg-slate-50">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="FAQ"
          title="Common questions from UAE families"
          desc="Everything you need to know before getting started."
        />
        <div className="mt-10 space-y-3">
          {aeFaqs.map((item, i) => {
            const isOpen = open === i
            return (
              <div key={i} className="bg-white rounded-xl border border-slate-200 overflow-hidden">
                <button
                  type="button"
                  onClick={() => setOpen(isOpen ? -1 : i)}
                  className="w-full flex items-center justify-between gap-4 p-5 text-left hover:bg-slate-50 transition-colors"
                  aria-expanded={isOpen}
                >
                  <span className="font-semibold text-slate-900 text-sm">{item.q}</span>
                  <span className={`flex-none flex h-7 w-7 items-center justify-center rounded-full text-sm transition-all ${isOpen ? 'bg-blue-900 text-white rotate-45' : 'bg-slate-100 text-slate-600'}`}>
                    +
                  </span>
                </button>
                {isOpen && (
                  <div className="px-5 pb-5 pt-0 text-sm text-slate-700 leading-relaxed animate-fade-in">
                    {item.a}
                  </div>
                )}
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}

/* ============================================================
   FINAL CTA
   ============================================================ */

function FinalCTA() {
  return (
    <section className="py-16 sm:py-20 bg-gradient-to-br from-blue-900 via-blue-950 to-slate-900 text-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-balance">
          Ready to find the right tutor for your child?
        </h2>
        <p className="mt-4 text-base sm:text-lg text-blue-100/90 max-w-2xl mx-auto leading-relaxed">
          Get matched with 2–3 verified UAE-aligned tutors in 3 minutes. Free educational
          consultant consultation. Free demo class. No commitment until you're ready.
        </p>
        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <Link
            to="/ae/find-tutor"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-white text-slate-900 font-semibold hover:bg-amber-50 transition-colors shadow-lg"
          >
            Find My Tutor →
          </Link>
          <a
            href={`tel:${SITE.phoneHref}`}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl border border-white/30 text-white hover:bg-white/10 transition-colors"
          >
            📞 {SITE.phoneDisplay}
          </a>
          <Link
            to="/ae/contact"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl text-blue-100 hover:text-amber-300 transition-colors"
          >
            Free Consultation →
          </Link>
        </div>
      </div>
    </section>
  )
}

/* ============================================================
   Shared sub-component
   ============================================================ */

function SectionHeading({ eyebrow, title, desc }) {
  return (
    <div className="text-center">
      <p className="text-xs font-semibold uppercase tracking-wider text-amber-700 mb-3">{eyebrow}</p>
      <h2 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 text-balance">
        {title}
      </h2>
      {desc && (
        <p className="mt-4 text-base text-slate-600 max-w-2xl mx-auto leading-relaxed text-pretty">
          {desc}
        </p>
      )}
    </div>
  )
}
